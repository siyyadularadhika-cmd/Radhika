self.addEventListener("install", function(event) {
  event.waitUntil(
    caches.open("citycare-cache").then(function(cache) {
      return cache.addAll([
        "index.html",
        "patient.html",
        "doctor.html",
        "admin.html"
      ]);
    })
  );
});